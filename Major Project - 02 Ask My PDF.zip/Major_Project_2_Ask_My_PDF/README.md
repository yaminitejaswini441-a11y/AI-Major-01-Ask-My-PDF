# Ask My PDF

## Project Description
A PDF question-answering system that retrieves
relevant text from uploaded PDF documents.

## Technologies Used
- Python
- Streamlit
- PyPDF
- Scikit-learn

## Features
- Upload PDF documents
- Extract PDF text
- Enter questions
- Retrieve relevant text sections

## How To Run
1. Install requirements.
2. Run app.py using Streamlit.
3. Upload a PDF and ask a question.