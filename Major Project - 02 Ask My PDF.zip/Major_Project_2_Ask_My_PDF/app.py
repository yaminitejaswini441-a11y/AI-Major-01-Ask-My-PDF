import streamlit as st
from pypdf import PdfReader
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import re

st.set_page_config(
    page_title="Ask My PDF",
    page_icon="📄",
    layout="centered"
)

st.title("📄 Ask My PDF")
st.write("Upload a PDF and ask questions about its content.")

uploaded_file = st.file_uploader(
    "Upload Your PDF File",
    type=["pdf"]
)

def clean_text(text):
    return re.sub(r"\s+", " ", text).strip()

def split_into_chunks(text, chunk_size=100):
    words = text.split()
    chunks = []

    for i in range(0, len(words), chunk_size):
        chunk = " ".join(words[i:i + chunk_size])
        if chunk:
            chunks.append(chunk)

    return chunks

if uploaded_file is not None:
    try:
        reader = PdfReader(uploaded_file)

        pages = []
        for page in reader.pages:
            pages.append(page.extract_text() or "")

        full_text = clean_text(" ".join(pages))

        if not full_text:
            st.error(
                "No readable text found. "
                "Please upload a text-based PDF."
            )
            st.stop()

        chunks = split_into_chunks(full_text)

        st.success("PDF Uploaded Successfully!")
        st.write(f"Total Pages: {len(reader.pages)}")
        st.write(f"Total Text Sections: {len(chunks)}")

        question = st.text_input(
            "Enter Your Question About The PDF"
        )

        if st.button("Get Answer"):
            if not question.strip():
                st.warning("Please Enter A Question.")
            elif len(chunks) < 2:
                st.info(
                    "PDF Text Is Too Short For Reliable Matching."
                )
                st.write(chunks[0])
            else:
                vectorizer = TfidfVectorizer(
                    stop_words="english"
                )

                matrix = vectorizer.fit_transform(
                    chunks + [question]
                )

                scores = cosine_similarity(
                    matrix[-1],
                    matrix[:-1]
                ).flatten()

                best_index = scores.argmax()
                best_score = scores[best_index]

                if best_score < 0.05:
                    st.warning(
                        "Relevant Information Was Not Found "
                        "In The PDF."
                    )
                else:
                    st.subheader("Answer From PDF")
                    st.write(chunks[best_index])

    except Exception as error:
        st.error(f"Unable To Read PDF: {error}")